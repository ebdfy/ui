// src/floor.ts
if (!("shadowRootMode" in HTMLTemplateElement.prototype) || new URLSearchParams(location.search).get("floor") === "old") {
	let e = document.documentElement.lang.startsWith("bn") ? {
		heading: "ebdfy ব্যবহার করতে ব্রাউজার আপডেট করুন",
		line: "এই ব্রাউজারটি ebdfy চালানোর জন্য অনেক পুরনো।",
		link: "Google Play থেকে Chrome নিন"
	} : {
		heading: "Update your browser to use ebdfy",
		line: "This browser is too old for ebdfy.",
		link: "Get Chrome on Google Play"
	};
	if (!document.querySelector("meta[name=\"viewport\"]")) {
		let e = document.createElement("meta");
		e.name = "viewport", e.content = "width=device-width, initial-scale=1", document.head.append(e);
	}
	let t = document.createElement("main");
	t.style.cssText = "box-sizing:border-box;max-width:32rem;margin:0 auto;padding:32px 16px;font-family:system-ui,-apple-system,\"Segoe UI\",Roboto,sans-serif;color:#1a1a1a;background:#fff;line-height:1.5";
	let n = document.createElement("h1");
	n.style.cssText = "margin:0 0 12px;font-size:1.5rem;line-height:1.3", n.textContent = e.heading;
	let r = document.createElement("p");
	r.style.cssText = "margin:0 0 24px", r.textContent = e.line;
	let i = document.createElement("a");
	i.href = "https://play.google.com/store/apps/details?id=com.android.chrome", i.style.cssText = "box-sizing:border-box;display:inline-flex;align-items:center;min-height:44px;padding:0 20px;border-radius:8px;background:#2340b8;color:#fff;font-weight:600;text-decoration:none", i.textContent = e.link, t.append(n, r, i), document.body.style.background = "#fff", document.body.replaceChildren(t);
}
// src/v2/form-errors.ts
var e = (e, t) => (e.constructor.observedAttributes ?? []).includes(t), t = (t) => {
	for (let n = t.parentElement; n; n = n.parentElement) if (n.localName.startsWith("e-")) return e(n, "error") ? n : null;
	return null;
}, n = (e) => e === "error" || e.endsWith("-error");
function r(e) {
	for (let t of e.querySelectorAll("*")) if (t.localName.startsWith("e-")) for (let e of t.getAttributeNames()) n(e) && t.removeAttribute(e);
	e.querySelector(":scope > [data-e-form-errors]")?.remove();
	let t = e.querySelector(":scope > [data-e-announce]");
	t && (t.textContent = "");
}
function i(n, r, i) {
	let a = [...n.elements].find((e) => "name" in e && e.name === r), o = a && t(a);
	if (!a || !o) return null;
	let s = `${r.split(".").pop()}-error`;
	return o.setAttribute(e(o, s) ? s : "error", i), a;
}
function a(e) {
	return e instanceof HTMLInputElement && e.type === "hidden" ? t(e)?.querySelector("input:not([type=\"hidden\"]), select, textarea") ?? null : e;
}
function o(e, t) {
	r(e);
	let n = [], o = [];
	for (let r of t) {
		let t = r.field?.length ? i(e, r.field.join("."), r.message) : null;
		t ? n.push(t) : o.push(r);
	}
	if (o.length) {
		let t = document.createElement("div");
		t.dataset.eFormErrors = "", t.append(...o.map((e) => Object.assign(document.createElement("p"), { textContent: e.message }))), e.prepend(t);
	}
	let c = e.querySelector(":scope > [data-e-announce]");
	c || (c = document.createElement("div"), c.dataset.eAnnounce = "", c.setAttribute("aria-live", "assertive"), e.append(c)), c.textContent = t.map((e) => e.message).join(" ");
	let l = [...e.elements].find((e) => n.includes(e));
	l && a(l)?.focus(), t.length && e.dispatchEvent(new Event(s, { bubbles: !0 }));
}
// src/save-bar.ts
var s = "e-save-refused";
function c({ value: e, checked: t }) {
	return {
		value: e,
		checked: t
	};
}
function l(e, t) {
	t.value !== void 0 && (e.value = t.value), t.checked !== void 0 && (e.checked = t.checked);
}
function u(e) {
	return !("name" in e) || !e.name ? !1 : !(e instanceof HTMLInputElement && [
		"search",
		"submit",
		"button",
		"reset"
	].includes(e.type));
}
var d = (e) => [...e.elements].filter(u), ee = (e, t) => JSON.stringify(e) === JSON.stringify(t);
function te(e) {
	let t = e && "form" in e ? e.form : null;
	return t instanceof HTMLFormElement && t.hasAttribute("data-save-bar") ? t : null;
}
function f(e, t) {
	let n = (t) => (t.closest("e-modal > dialog") ?? t.ownerDocument) === e, i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = !1, f = (e) => {
		let t = i.get(e) ?? /* @__PURE__ */ new Map();
		i.set(e, t);
		for (let n of d(e)) t.has(n) || t.set(n, c(n));
	}, p = () => {
		for (let t of e.querySelectorAll("form[data-save-bar]")) n(t) && f(t);
	}, m = (e) => [...i.get(e) ?? []].some(([e, t]) => e.isConnected && !ee(t, c(e))), h = () => {
		for (let e of i.keys()) e.isConnected || i.delete(e);
		let e = [...i.keys()].some(m);
		e !== o && t(o = e);
	}, g = (e) => {
		let t = te(e.target);
		t && n(t) && e.target instanceof Element && u(e.target) && (f(t), h());
	};
	return e.addEventListener("input", g), e.addEventListener("change", g), e.addEventListener("submit", (e) => {
		let t = e.target;
		t instanceof HTMLFormElement && i.has(t) && (a.set(t, i.get(t)), i.set(t, new Map(d(t).map((e) => [e, c(e)]))), h());
	}), e.addEventListener(s, (e) => {
		let t = e.target, n = t instanceof HTMLFormElement ? a.get(t) : void 0;
		n && t instanceof HTMLFormElement && (a.delete(t), i.set(t, n), h());
	}), new MutationObserver(p).observe(e, {
		childList: !0,
		subtree: !0
	}), p(), { act(e) {
		if (e === "discard") {
			for (let [e, t] of i) {
				for (let [e, n] of t) l(e, n);
				r(e);
			}
			h();
		} else for (let e of [...i.keys()].filter(m)) e.requestSubmit();
	} };
}
var p = /* @__PURE__ */ new Set(["https://admin.ebdfy.com", "https://ui.ebdfy.com"]), m = /^http:\/\/(localhost|127\.0\.0\.1):\d+$/;
function h(e, t) {
	return p.has(e) || t && m.test(e);
}
function g(e, t = !1) {
	if (e.parent === e) return null;
	let n = e.location.ancestorOrigins?.[0] ?? (e.document.referrer ? new URL(e.document.referrer).origin : "");
	return h(n, t) ? n : null;
}
function ne(e) {
	let t = e.querySelector("meta[name=\"ebdfy-home\"]")?.content;
	if (!t) return null;
	try {
		return new URL(t);
	} catch {
		return null;
	}
}
function re(e, t = !1) {
	if (e.top !== e) return null;
	let n = new URLSearchParams(e.location.search).get("store");
	if (!n) return null;
	let r = e.document.querySelector("meta[name=\"ebdfy-app\"]")?.content;
	if (!r) return console.warn("ebdfy: add <meta name=\"ebdfy-app\" content=\"<app handle>\"> so a ?store link opens in the Admin"), null;
	let i = ne(e.document);
	if (i && h(i.origin, t)) {
		let t = new URLSearchParams(e.location.search);
		return t.delete("store"), i.searchParams.set("page", t.size ? `${e.location.pathname}?${t}` : e.location.pathname), i.href;
	}
	return `https://admin.ebdfy.com/store/${encodeURIComponent(n)}/apps/${encodeURIComponent(r)}`;
}
function ie(e) {
	let t = e.activeElement;
	for (; t?.shadowRoot?.activeElement;) t = t.shadowRoot.activeElement;
	return t instanceof HTMLElement ? t : null;
}
function ae(e = window) {
	let t = g(e), n = (n) => {
		t && e.parent.postMessage(n, t);
	}, r = null, i = 0, a = [], o = 0, s, c = 0, l = /* @__PURE__ */ new Map(), u = () => {
		if (!t) return Promise.reject(/* @__PURE__ */ Error("ebdfy: an ID token comes only from the Admin, and this page is not in it"));
		c += 1;
		let e = c;
		return new Promise((t, r) => {
			l.set(e, ({ token: e, api: n, error: i }) => {
				e && n ? t({
					token: e,
					api: n
				}) : r(/* @__PURE__ */ Error(`ebdfy: no ID token: ${i ?? "the Admin gave none"}`));
			}), n({
				type: "idToken",
				payload: { id: e }
			});
		});
	};
	if (t) {
		let c = f(e.document, (e) => n({
			type: "saveBar",
			payload: { visible: e }
		}));
		n({
			type: "saveBar",
			payload: { visible: !1 }
		}), n({
			type: "loading",
			payload: { visible: !1 }
		}), e.addEventListener("keydown", (e) => {
			e.key === "Escape" && !e.defaultPrevented && n({ type: "modalClose" });
		}), e.addEventListener("message", (n) => {
			if (n.source !== e.parent || n.origin !== t) return;
			if (n.data?.type === "titleAction") {
				let { call: e, index: t, item: r } = n.data.payload ?? {}, o = e === i ? a[Number(t)] : void 0;
				r === void 0 ? o?.onAction?.() : o?.items?.[Number(r)]?.onAction?.();
			}
			if (n.data?.type === "toastAction" && n.data.payload?.call === o) {
				let e = s;
				s = void 0, e?.onAction();
			}
			if (n.data?.type === "idToken") {
				let e = n.data.payload;
				l.get(e?.id)?.(e), l.delete(e?.id);
			}
			n.data?.type === "modalClosed" && (r?.focus(), r = null);
			let u = n.data?.type === "theme" ? n.data.payload?.theme : void 0;
			(u === "light" || u === "dark") && (e.document.documentElement.dataset.theme = u);
			let d = n.data?.type === "saveBar" ? n.data.payload?.action : void 0;
			(d === "save" || d === "discard") && c.act(d);
		}), n({
			type: "ready",
			payload: { page: e.location.href }
		});
	}
	return {
		toast(e, t = {}) {
			s = t.action, o += 1;
			let r = t.action ? String(t.action.label) : void 0, i = t.error === !0 || t.tone === "danger";
			n({
				type: "toast",
				payload: {
					message: String(e),
					error: i,
					action: r,
					call: o
				}
			});
		},
		title(e, t = {}) {
			let r = t.actions ?? [];
			r.length > 2 && console.warn("ebdfy: at most 2 title actions"), a = r.slice(0, 2), i += 1;
			let o = a.map((e) => String(e.label)), s = {
				title: String(e),
				actions: o,
				call: i
			};
			a.some((e) => e.items) && (s.menus = a.map((e) => e.items?.map((e) => e.tone === "critical" ? {
				label: String(e.label),
				tone: e.tone
			} : { label: String(e.label) }) ?? null)), t.back !== void 0 && (s.back = String(t.back)), n({
				type: "title",
				payload: s
			});
		},
		loading(e) {
			n({
				type: "loading",
				payload: { visible: e === !0 }
			});
		},
		async idToken() {
			return (await u()).token;
		},
		async fetch(t, n = {}) {
			let { token: r, api: i } = await u();
			return (await e.fetch(i, {
				method: "POST",
				headers: {
					authorization: `Bearer ${r}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({
					query: String(t),
					variables: n
				})
			})).json();
		},
		modal(t) {
			r = ie(e.document);
			let { src: i, size: a = "medium", title: o = "" } = t, s = () => n({
				type: "modal",
				payload: {
					src: String(i),
					size: a,
					title: String(o)
				}
			});
			e.document.readyState === "complete" ? s() : e.addEventListener("load", () => setTimeout(s), { once: !0 });
		},
		closeModal() {
			n({ type: "modalClose" });
		},
		nav(e) {
			e.length > 8 && console.warn("ebdfy: at most 8 nav entries");
			let t = e.slice(0, 8).map(({ label: e, path: t, icon: n, count: r }) => {
				let i = {
					label: String(e),
					path: String(t)
				};
				return n !== void 0 && (i.icon = String(n)), r !== void 0 && (i.count = Number(r)), i;
			});
			n({
				type: "nav",
				payload: { entries: t }
			});
		}
	};
}
// src/format.ts
function _() {
	return document.documentElement.lang.startsWith("bn") ? "bn" : "en";
}
var oe = {
	bn: new Intl.NumberFormat("bn-IN", { maximumFractionDigits: 2 }),
	en: new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 })
};
function v(e, t = _()) {
	return oe[t].format(e);
}
function se(e, t = _()) {
	return `৳${v(e, t)}`;
}
function y(e) {
	return e.replace(/[০-৯]/g, (e) => String(e.charCodeAt(0) - 2534));
}
// src/v2/avatar.ts
var ce = class extends HTMLElement {
	static observedAttributes = ["name"];
	connectedCallback() {
		this.fill();
	}
	attributeChangedCallback() {
		this.fill();
	}
	fill() {
		let e = this.getAttribute("name") ?? "";
		this.setAttribute("role", "img"), e ? this.setAttribute("aria-label", e) : this.removeAttribute("aria-label");
		let t = e.split(/\s+/).filter(Boolean), n = [t[0], t.length > 1 ? t[t.length - 1] : void 0].map((e) => e ? Array.from(e)[0] ?? "" : "").join("");
		n ? this.setAttribute("initials", n.toLocaleUpperCase()) : this.removeAttribute("initials");
	}
};
function le() {
	customElements.get("e-avatar") || customElements.define("e-avatar", ce);
}
// src/lang.ts
function b(e) {
	return e.closest("[lang]")?.getAttribute("lang")?.startsWith("bn") ? "bn" : "en";
}
// src/v2/banner.ts
var ue = "a[href], button, input, select, textarea, summary, [tabindex]:not([tabindex=\"-1\"])";
function de(e) {
	let t;
	for (let n of document.querySelectorAll(ue)) if (!(e.contains(n) || n.matches(":disabled") || !n.checkVisibility())) {
		if (e.compareDocumentPosition(n) & Node.DOCUMENT_POSITION_FOLLOWING) return n;
		t = n;
	}
	return t;
}
var fe = class extends HTMLElement {
	static observedAttributes = ["heading", "tone"];
	connectedCallback() {
		if (this.attributeChangedCallback(), this.hasAttribute("dismissible")) {
			this.querySelector(":scope > [slot=\"dismiss\"]") || this.append(this.#e()), this.#n();
			for (let e of /* @__PURE__ */ new Set([this.closest("[lang]"), document.documentElement])) e && this.#t.observe(e, { attributeFilter: ["lang"] });
		}
	}
	#e() {
		let e = document.createElement("button");
		return e.type = "button", e.slot = "dismiss", e.innerHTML = "<e-icon name=\"x\"></e-icon>", e.addEventListener("click", () => {
			let e = de(this);
			this.dispatchEvent(new CustomEvent("dismiss", {
				bubbles: !0,
				cancelable: !0
			})) && (this.hidden = !0, e?.focus());
		}), e;
	}
	disconnectedCallback() {
		this.#t.disconnect();
	}
	#t = new MutationObserver(() => this.#n());
	#n() {
		this.querySelector(":scope > [slot=\"dismiss\"]")?.setAttribute("aria-label", b(this) === "bn" ? "বন্ধ করুন" : "Dismiss");
	}
	attributeChangedCallback() {
		this.getAttribute("tone") === "critical" ? this.setAttribute("role", "alert") : this.removeAttribute("role");
		let e = this.getAttribute("heading"), t = this.querySelector(":scope > [slot=\"heading\"]");
		e === null ? t?.remove() : (t || (t = document.createElement("p"), t.slot = "heading", this.prepend(t)), t.textContent = e);
	}
};
function pe() {
	customElements.get("e-banner") || customElements.define("e-banner", fe);
}
// src/v2/bridge.ts
function me(e = window) {
	if (!g(e)) return;
	let t = new URLSearchParams(e.location.search).get("store");
	if (!t) return;
	let n = (n) => {
		let r = n.target instanceof Element ? n.target.closest("a[href]") : null;
		if (!r) return;
		let i = new URL(r.href);
		i.origin !== e.location.origin || i.searchParams.has("store") || (i.searchParams.set("store", t), r.href = i.href);
	};
	e.addEventListener("click", n, !0), e.addEventListener("auxclick", n, !0);
}
var he = "(width < 600px)";
function ge(e = window) {
	let t = g(e), n = {
		store: new URLSearchParams(e.location.search).get("store") ?? "",
		app: e.document.querySelector("meta[name=\"ebdfy-app\"]")?.content ?? ""
	}, r = {
		embedded: t !== null,
		mobile: e.matchMedia(he).matches
	}, i = null, a = () => {}, o = new Promise((e) => a = e);
	return t && e.addEventListener("message", (o) => {
		if (o.source !== e.parent || o.origin !== t || o.data?.type !== "context") return;
		let { store: s, app: c, mobile: l } = o.data.payload ?? {};
		n.store = String(s ?? ""), n.app = String(c ?? ""), r.mobile = l === !0, i = o.data.payload?.language === "bn" ? "bn" : "en", a();
		let u = {
			...n,
			language: i,
			...r
		};
		e.dispatchEvent(new CustomEvent("ebdfy:context", { detail: u }));
	}), {
		config: n,
		environment: r,
		async user() {
			if (!t) throw Error("ebdfy: the staff member comes only from the Admin, and this page is not in it");
			return await o, { language: i ?? "en" };
		}
	};
}
function _e(e = window) {
	let t = g(e);
	if (!t) return;
	let n = () => {
		let n = {
			type: "page",
			payload: { page: e.location.href }
		};
		e.parent.postMessage(n, t);
	};
	for (let t of ["pushState", "replaceState"]) {
		let r = e.history[t];
		e.history[t] = function(...e) {
			r.apply(this, e), n();
		};
	}
	e.addEventListener("popstate", n);
}
function ve(e = window) {
	let t = g(e);
	if (!t) return;
	let n = () => {
		let n = {
			type: "appModal",
			payload: { open: e.document.querySelector("e-modal > dialog[open]") !== null }
		};
		e.parent.postMessage(n, t);
	};
	e.addEventListener("e-modal-open", n), e.addEventListener("e-modal-close", n);
}
// src/v2/button-group.ts
var ye = class extends HTMLElement {
	static observedAttributes = ["label"];
	#e = new MutationObserver((e) => {
		for (let t of e) {
			let e = t.target;
			if (t.type === "attributes" && e instanceof Element && e.hasAttribute("pressed")) for (let t of this.#n()) t !== e && t.removeAttribute("pressed");
		}
		this.#r();
	});
	connectedCallback() {
		this.setAttribute("role", "group"), this.#t(), this.#r(), this.addEventListener("click", this.#i), this.#e.observe(this, {
			attributes: !0,
			attributeFilter: ["pressed"],
			childList: !0,
			subtree: !0
		});
	}
	disconnectedCallback() {
		this.removeEventListener("click", this.#i), this.#e.disconnect();
	}
	attributeChangedCallback() {
		this.isConnected && this.#t();
	}
	#t() {
		let e = this.getAttribute("label");
		e && this.setAttribute("aria-label", e);
	}
	#n() {
		return [...this.querySelectorAll(":scope > e-button")];
	}
	#r() {
		for (let e of this.#n()) {
			let t = e.querySelector(":scope > button");
			t && e.removeAttribute("aria-pressed"), (t ?? e).setAttribute("aria-pressed", String(e.hasAttribute("pressed")));
		}
	}
	#i = (e) => {
		let t = e.target instanceof Element ? e.target.closest("e-button") : null;
		if (!(!t || t.parentElement !== this || t.hasAttribute("pressed") || t.hasAttribute("disabled"))) {
			for (let e of this.#n()) e.toggleAttribute("pressed", e === t);
			this.#r(), this.dispatchEvent(new CustomEvent("e-button-group-change", {
				bubbles: !0,
				detail: { value: t.getAttribute("value") }
			}));
		}
	};
};
function be() {
	customElements.get("e-button-group") || customElements.define("e-button-group", ye);
}
// src/v2/button.ts
var xe = class extends HTMLElement {
	static observedAttributes = [
		"disabled",
		"type",
		"aria-label"
	];
	#e = null;
	connectedCallback() {
		if (!this.#e) {
			let e = this.querySelector(":scope > button") ?? document.createElement("button");
			e.isConnected || (e.append(...this.childNodes), this.append(e)), this.#e = e;
		}
		this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		let e = this.#e;
		if (!e) return;
		e.disabled = this.hasAttribute("disabled");
		let t = this.getAttribute("type");
		t === "button" || t === "submit" || t === "reset" ? e.type = t : e.removeAttribute("type");
		let n = this.getAttribute("aria-label");
		n === null ? e.removeAttribute("aria-label") : e.setAttribute("aria-label", n);
	}
};
function Se() {
	customElements.get("e-button") || customElements.define("e-button", xe);
}
// src/v2/card.ts
var Ce = class extends HTMLElement {
	static observedAttributes = ["heading"];
	connectedCallback() {
		this.#e(), this.#r();
	}
	attributeChangedCallback() {
		let e = this.querySelector(":scope > h2[slot=\"heading\"]");
		e && (e.textContent = this.getAttribute("heading") ?? "");
	}
	#e() {
		let e = this.getAttribute("heading");
		if (e === null || this.querySelector(":scope > h2[slot=\"heading\"]")) return;
		let t = document.createElement("h2");
		t.slot = "heading", t.textContent = e, this.prepend(t);
	}
	#t = [];
	#n = new MutationObserver(() => this.#i());
	#r() {
		let e = [...this.querySelectorAll(":scope > [slot=\"actions\"]")].slice(2);
		if (e.length === 0 || this.querySelector(":scope > [data-part=\"more\"]")) return;
		let t = document.createElement("e-menu");
		t.dataset.part = "more";
		let n = document.createElement("e-button");
		n.setAttribute("slot", "trigger"), t.append(n);
		for (let n of e) {
			let e = document.createElement("e-menu-item");
			e.addEventListener("click", () => {
				(n.querySelector(":scope > button, :scope > a") ?? n).click();
			}), t.append(e), this.#t.push([e, n]);
		}
		this.append(t), this.#i();
		let r = {
			subtree: !0,
			childList: !0,
			characterData: !0,
			attributeFilter: ["aria-label"]
		};
		for (let t of e) this.#n.observe(t, r);
		for (let e of /* @__PURE__ */ new Set([this.closest("[lang]"), document.documentElement])) e && this.#n.observe(e, { attributeFilter: ["lang"] });
	}
	#i() {
		let e = (e, t) => {
			e.textContent !== t && (e.textContent = t);
		}, t = this.querySelector(":scope > [data-part=\"more\"] > [slot=\"trigger\"]");
		if (t) {
			let n = this.closest("[lang]")?.getAttribute("lang")?.startsWith("bn");
			e(t.querySelector(":scope > button") ?? t, n ? "আরও" : "More");
		}
		for (let [t, n] of this.#t) e(t, n.getAttribute("aria-label") ?? n.textContent?.trim() ?? "");
	}
};
function we() {
	customElements.get("e-card") || customElements.define("e-card", Ce);
}
// src/v2/field.ts
var Te = [
	"name",
	"value",
	"placeholder",
	"type",
	"inputmode",
	"required",
	"autocomplete"
], x = 0;
function S(e, t) {
	let n = e.getAttribute("error"), r = e.querySelector(":scope > [data-e-error]");
	n ? (r || (r = document.createElement("p"), r.dataset.eError = "", r.id = `e-error-${++x}`, e.append(r)), r.textContent = n, t.setAttribute("aria-invalid", "true"), t.setAttribute("aria-describedby", r.id)) : (r?.remove(), t.removeAttribute("aria-invalid"), t.removeAttribute("aria-describedby"));
}
var C = class extends HTMLElement {
	static observedAttributes = [
		"label",
		"placeholder",
		"error"
	];
	#e = null;
	get value() {
		return this.#e?.value ?? this.getAttribute("value") ?? "";
	}
	set value(e) {
		this.#e ? this.#e.value = e : this.setAttribute("value", e);
	}
	connectedCallback() {
		if (this.#e) return;
		let e = this.create();
		for (let t of Te) {
			let n = this.getAttribute(t);
			n === null || e instanceof HTMLTextAreaElement && t === "type" || (e instanceof HTMLTextAreaElement && t === "value" ? e.value = n : e.setAttribute(t, n));
		}
		this.#e = e, this.build(e, this.getAttribute("label") ?? ""), S(this, e);
	}
	attributeChangedCallback(e, t, n) {
		let r = this.#e;
		r && (e === "label" ? this.relabel(r, n ?? "") : e === "error" ? S(this, r) : n === null ? r.removeAttribute(e) : r.setAttribute(e, n));
	}
	create() {
		return document.createElement("input");
	}
}, w = class extends C {
	build(e, t) {
		e.id = `e-field-${++x}`;
		let n = document.createElement("label");
		n.htmlFor = e.id, n.textContent = t, this.append(n, e);
	}
	relabel(e, t) {
		let n = e.labels?.[0];
		n && (n.textContent = t);
	}
}, Ee = class extends w {
	create() {
		let e = document.createElement("input");
		return e.type = "date", e;
	}
}, De = class extends w {
	create() {
		return document.createElement("textarea");
	}
}, Oe = class extends C {
	build(e, t) {
		e instanceof HTMLInputElement && (e.type = "search"), e.setAttribute("aria-label", t);
		let n = document.createElement("e-icon");
		n.setAttribute("name", "search"), this.append(n, e);
	}
	relabel(e, t) {
		e.setAttribute("aria-label", t);
	}
};
function ke() {
	customElements.get("e-text-field") || customElements.define("e-text-field", w), customElements.get("e-date-field") || customElements.define("e-date-field", Ee), customElements.get("e-text-area") || customElements.define("e-text-area", De), customElements.get("e-search-field") || customElements.define("e-search-field", Oe);
}
// src/v2/checkbox.ts
var Ae = 0, je = class extends HTMLElement {
	static observedAttributes = [
		"label",
		"disabled",
		"indeterminate",
		"error"
	];
	#e = null;
	get checked() {
		return this.#e ? this.#e.checked : this.hasAttribute("checked");
	}
	set checked(e) {
		this.#e ? this.#e.checked = e : this.toggleAttribute("checked", e);
	}
	get indeterminate() {
		return this.hasAttribute("indeterminate");
	}
	set indeterminate(e) {
		this.toggleAttribute("indeterminate", e);
	}
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("input");
		e.type = "checkbox", e.id = `e-checkbox-${++Ae}`;
		for (let t of ["name", "value"]) {
			let n = this.getAttribute(t);
			n !== null && e.setAttribute(t, n);
		}
		e.disabled = this.hasAttribute("disabled"), e.checked = this.hasAttribute("checked"), this.#e = e, this.#t(), e.addEventListener("change", () => {
			e.indeterminate || this.removeAttribute("indeterminate");
		}), this.addEventListener("click", (t) => {
			t.target === this && e.click();
		});
		let t = this.getAttribute("label") ?? "";
		if (this.hasAttribute("hide-label")) e.setAttribute("aria-label", t), this.append(e);
		else {
			let n = document.createElement("label");
			n.htmlFor = e.id, n.textContent = t, this.append(e, n);
		}
		S(this, e);
	}
	attributeChangedCallback(e, t, n) {
		let r = this.#e;
		r && (e === "label" ? this.hasAttribute("hide-label") ? r.setAttribute("aria-label", n ?? "") : r.labels[0].textContent = n ?? "" : e === "disabled" ? r.disabled = n !== null : e === "error" ? S(this, r) : this.#t());
	}
	#t() {
		let e = this.#e;
		e.indeterminate = this.hasAttribute("indeterminate"), e.indeterminate ? e.setAttribute("aria-checked", "mixed") : e.removeAttribute("aria-checked");
	}
};
function Me() {
	customElements.get("e-checkbox") || customElements.define("e-checkbox", je);
}
// src/v2/choice-list.ts
var Ne = 0, Pe = class extends HTMLElement {
	static observedAttributes = ["label", "error"];
	#e = null;
	get value() {
		return this.querySelector(":scope > label > input:checked")?.value ?? "";
	}
	set value(e) {
		for (let t of this.querySelectorAll(":scope > label > input")) t.checked = t.value === e;
	}
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("span");
		e.id = `e-choice-list-${++Ne}`, e.dataset.part = "label", this.#e = e, this.setAttribute("role", "radiogroup"), this.setAttribute("aria-labelledby", e.id);
		let t = this.getAttribute("name") ?? e.id;
		for (let e of this.querySelectorAll(":scope > option")) {
			let n = document.createElement("input");
			n.type = "radio", n.name = t, n.value = e.value, n.checked = e.hasAttribute("selected"), n.disabled = this.hasAttribute("disabled") || e.disabled;
			let r = document.createElement("label");
			r.append(n, ...e.childNodes), e.replaceWith(r);
		}
		this.prepend(e), this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		this.#e && (this.#e.textContent = this.getAttribute("label") ?? "", S(this, this));
	}
};
function Fe() {
	customElements.get("e-choice-list") || customElements.define("e-choice-list", Pe);
}
// src/v2/speech.ts
var T = /* @__PURE__ */ new Set(), E;
function D(e) {
	return E ??= new MutationObserver(() => {
		for (let e of T) e();
	}), E.observe(document.documentElement, {
		attributes: !0,
		attributeFilter: ["lang"]
	}), T.add(e), () => T.delete(e);
}
// src/v2/courier-status.ts
var O = {
	"awaiting-pickup": ["Awaiting pickup", "পিকআপের অপেক্ষায়"],
	"picked-up": ["Picked up", "পিকআপ হয়েছে"],
	"with-courier": ["With courier", "কুরিয়ারে"],
	"out-for-delivery": ["Out for delivery", "ডেলিভারির পথে"],
	"on-hold": ["On hold", "আটকে আছে"],
	"delivery-failed": ["Delivery failed", "ডেলিভারি হয়নি"],
	delivered: ["Delivered", "ডেলিভারি হয়েছে"],
	"partly-delivered": ["Partly delivered", "আংশিক ডেলিভারি"],
	returning: ["Returning", "ফেরত আসছে"],
	returned: ["Returned", "ফেরত এসেছে"],
	cancelled: ["Cancelled", "বাতিল"],
	problem: ["Problem", "সমস্যা"],
	unknown: ["Unknown", "অজানা"]
}, k = {
	PENDING: "awaiting-pickup",
	PICKED_UP: "picked-up",
	IN_TRANSIT: "with-courier",
	OUT_FOR_DELIVERY: "out-for-delivery",
	ON_HOLD: "on-hold",
	ATTEMPT_FAILED: "delivery-failed",
	DELIVERED: "delivered",
	PARTIAL_DELIVERED: "partly-delivered",
	RETURNING: "returning",
	RETURNED: "returned",
	CANCELLED: "cancelled",
	EXCEPTION: "problem",
	UNKNOWN: "unknown"
}, Ie = class extends HTMLElement {
	static observedAttributes = ["status"];
	#e;
	connectedCallback() {
		this.#e = D(() => this.#t()), this.#t();
	}
	disconnectedCallback() {
		this.#e?.();
	}
	attributeChangedCallback() {
		this.isConnected && this.#t();
	}
	#t() {
		let e = this.getAttribute("status") ?? "", t = Object.hasOwn(k, e) ? k[e] : e, [n, r] = Object.hasOwn(O, t) ? O[t] : O.unknown;
		this.textContent = b(this) === "bn" ? r : n;
	}
};
function Le() {
	customElements.get("e-courier-status") || customElements.define("e-courier-status", Ie);
}
// src/geo/districts.ts
var Re = [
	{
		name: "Bagerhat",
		nameBn: "বাগেরহাট"
	},
	{
		name: "Bandarban",
		nameBn: "বান্দরবান"
	},
	{
		name: "Barguna",
		nameBn: "বরগুনা"
	},
	{
		name: "Barishal",
		nameBn: "বরিশাল"
	},
	{
		name: "Bhola",
		nameBn: "ভোলা"
	},
	{
		name: "Bogura",
		nameBn: "বগুড়া"
	},
	{
		name: "Brahmanbaria",
		nameBn: "ব্রাহ্মণবাড়িয়া"
	},
	{
		name: "Chandpur",
		nameBn: "চাঁদপুর"
	},
	{
		name: "Chapai Nawabganj",
		nameBn: "চাঁপাইনবাবগঞ্জ"
	},
	{
		name: "Chattogram",
		nameBn: "চট্টগ্রাম"
	},
	{
		name: "Chuadanga",
		nameBn: "চুয়াডাঙ্গা"
	},
	{
		name: "Cox's Bazar",
		nameBn: "কক্সবাজার"
	},
	{
		name: "Cumilla",
		nameBn: "কুমিল্লা"
	},
	{
		name: "Dhaka",
		nameBn: "ঢাকা"
	},
	{
		name: "Dinajpur",
		nameBn: "দিনাজপুর"
	},
	{
		name: "Faridpur",
		nameBn: "ফরিদপুর"
	},
	{
		name: "Feni",
		nameBn: "ফেনী"
	},
	{
		name: "Gaibandha",
		nameBn: "গাইবান্ধা"
	},
	{
		name: "Gazipur",
		nameBn: "গাজীপুর"
	},
	{
		name: "Gopalganj",
		nameBn: "গোপালগঞ্জ"
	},
	{
		name: "Habiganj",
		nameBn: "হবিগঞ্জ"
	},
	{
		name: "Jamalpur",
		nameBn: "জামালপুর"
	},
	{
		name: "Jashore",
		nameBn: "যশোর"
	},
	{
		name: "Jhalokati",
		nameBn: "ঝালকাঠি"
	},
	{
		name: "Jhenaidah",
		nameBn: "ঝিনাইদহ"
	},
	{
		name: "Joypurhat",
		nameBn: "জয়পুরহাট"
	},
	{
		name: "Khagrachhari",
		nameBn: "খাগড়াছড়ি"
	},
	{
		name: "Khulna",
		nameBn: "খুলনা"
	},
	{
		name: "Kishoreganj",
		nameBn: "কিশোরগঞ্জ"
	},
	{
		name: "Kurigram",
		nameBn: "কুড়িগ্রাম"
	},
	{
		name: "Kushtia",
		nameBn: "কুষ্টিয়া"
	},
	{
		name: "Lakshmipur",
		nameBn: "লক্ষ্মীপুর"
	},
	{
		name: "Lalmonirhat",
		nameBn: "লালমনিরহাট"
	},
	{
		name: "Madaripur",
		nameBn: "মাদারীপুর"
	},
	{
		name: "Magura",
		nameBn: "মাগুরা"
	},
	{
		name: "Manikganj",
		nameBn: "মানিকগঞ্জ"
	},
	{
		name: "Meherpur",
		nameBn: "মেহেরপুর"
	},
	{
		name: "Moulvibazar",
		nameBn: "মৌলভীবাজার"
	},
	{
		name: "Munshiganj",
		nameBn: "মুন্সীগঞ্জ"
	},
	{
		name: "Mymensingh",
		nameBn: "ময়মনসিংহ"
	},
	{
		name: "Naogaon",
		nameBn: "নওগাঁ"
	},
	{
		name: "Narail",
		nameBn: "নড়াইল"
	},
	{
		name: "Narayanganj",
		nameBn: "নারায়ণগঞ্জ"
	},
	{
		name: "Narsingdi",
		nameBn: "নরসিংদী"
	},
	{
		name: "Natore",
		nameBn: "নাটোর"
	},
	{
		name: "Netrokona",
		nameBn: "নেত্রকোণা"
	},
	{
		name: "Nilphamari",
		nameBn: "নীলফামারী"
	},
	{
		name: "Noakhali",
		nameBn: "নোয়াখালী"
	},
	{
		name: "Pabna",
		nameBn: "পাবনা"
	},
	{
		name: "Panchagarh",
		nameBn: "পঞ্চগড়"
	},
	{
		name: "Patuakhali",
		nameBn: "পটুয়াখালী"
	},
	{
		name: "Pirojpur",
		nameBn: "পিরোজপুর"
	},
	{
		name: "Rajbari",
		nameBn: "রাজবাড়ী"
	},
	{
		name: "Rajshahi",
		nameBn: "রাজশাহী"
	},
	{
		name: "Rangamati",
		nameBn: "রাঙ্গামাটি"
	},
	{
		name: "Rangpur",
		nameBn: "রংপুর"
	},
	{
		name: "Satkhira",
		nameBn: "সাতক্ষীরা"
	},
	{
		name: "Shariatpur",
		nameBn: "শরীয়তপুর"
	},
	{
		name: "Sherpur",
		nameBn: "শেরপুর"
	},
	{
		name: "Sirajganj",
		nameBn: "সিরাজগঞ্জ"
	},
	{
		name: "Sunamganj",
		nameBn: "সুনামগঞ্জ"
	},
	{
		name: "Sylhet",
		nameBn: "সিলেট"
	},
	{
		name: "Tangail",
		nameBn: "টাঙ্গাইল"
	},
	{
		name: "Thakurgaon",
		nameBn: "ঠাকুরগাঁও"
	}
], A = {
	en: {
		district: "District",
		upazila: "Upazila",
		chooseDistrict: "Choose a district",
		chooseUpazila: "Choose an upazila"
	},
	bn: {
		district: "জেলা",
		upazila: "উপজেলা",
		chooseDistrict: "জেলা বাছুন",
		chooseUpazila: "উপজেলা বাছুন"
	}
}, ze = import.meta.url, j, M = null;
async function Be() {
	try {
		let e = await fetch(new URL("areas.json", ze));
		e.ok && (M = await e.json());
	} catch {}
	return M || (j = void 0), M;
}
var N = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value"), Ve = 0, He = class extends HTMLElement {
	static observedAttributes = ["error", "upazila-error"];
	#e = null;
	#t = null;
	#n;
	connectedCallback() {
		if (this.#n = D(() => this.#a()), this.#e) return;
		let e = this.getAttribute("name"), t = this.#r("district", e), n = this.#r("upazila", e);
		this.#e = t, this.#t = n, Object.defineProperty(t, "value", {
			configurable: !0,
			get: () => N.get.call(t),
			set: (e) => {
				N.set.call(t, e), this.#o("");
			}
		}), t.addEventListener("input", () => this.#o("")), this.#a(), N.set.call(t, this.getAttribute("district") ?? ""), this.#o(this.getAttribute("upazila") ?? ""), M || (j ??= Be()).then(() => this.#o(N.get.call(n))), this.#i();
	}
	disconnectedCallback() {
		this.#n?.();
	}
	attributeChangedCallback() {
		this.#e && this.#i();
	}
	#r(e, t) {
		let n = document.createElement("select");
		n.id = `e-district-picker-${++Ve}`, n.name = t ? `${t}.${e}` : e;
		let r = document.createElement("label");
		r.htmlFor = n.id;
		let i = document.createElement("div");
		return i.append(r, n), this.append(i), n;
	}
	#i() {
		for (let [e, t] of [[this.#e, "error"], [this.#t, "upazila-error"]]) {
			let n = e.parentElement, r = this.getAttribute(t);
			r ? n.setAttribute("error", r) : n.removeAttribute("error"), S(n, e);
		}
	}
	#a() {
		let e = this.#e;
		if (!e) return;
		let t = b(this), n = A[t];
		e.labels[0].textContent = n.district, this.#t.labels[0].textContent = n.upazila;
		let r = N.get.call(e);
		e.replaceChildren(...P(n.chooseDistrict, Re.map((e) => [e.name, e.nameBn]), t)), N.set.call(e, r), this.#o(N.get.call(this.#t));
	}
	#o(e) {
		let t = this.#t, n = b(this), r = M?.[N.get.call(this.#e)] ?? [], i = P(A[n].chooseUpazila, r, n);
		!M && e && i.push(new Option("", e)), t.replaceChildren(...i), t.disabled = !M && !e, N.set.call(t, e), t.selectedIndex < 0 && (t.selectedIndex = 0);
	}
};
function P(e, t, n) {
	let r = t.map(([e, t]) => new Option(n === "bn" ? t : e, e.toLowerCase())).sort((e, t) => e.text.localeCompare(t.text, n));
	return [new Option(e, ""), ...r];
}
function Ue() {
	customElements.get("e-district-picker") || customElements.define("e-district-picker", He);
}
// src/v2/empty-state.ts
var We = class extends HTMLElement {
	static observedAttributes = ["heading"];
	connectedCallback() {
		let e = this.getAttribute("heading");
		if (e === null || this.querySelector(":scope > h2[slot=\"heading\"]")) return;
		let t = document.createElement("h2");
		t.slot = "heading", t.textContent = e, this.prepend(t);
	}
	attributeChangedCallback() {
		let e = this.querySelector(":scope > h2[slot=\"heading\"]");
		e && (e.textContent = this.getAttribute("heading") ?? "");
	}
};
function Ge() {
	customElements.get("e-empty-state") || customElements.define("e-empty-state", We);
}
// src/v2/fetch.ts
function Ke(e, { idToken: t, user: n }) {
	if (!g(e)) return;
	let r = e.fetch.bind(e);
	e.fetch = async (i, a) => {
		let o = new Request(i, a);
		if (new URL(o.url).origin !== e.location.origin) return r(o);
		let [s, { language: c }] = await Promise.all([t(), n()]);
		return o.headers.has("authorization") || o.headers.set("authorization", `Bearer ${s}`), o.headers.has("accept-language") || o.headers.set("accept-language", c), r(o);
	};
}
// src/v2/icon.ts
var qe = import.meta.url, F = "http://www.w3.org/2000/svg", Je;
async function Ye() {
	try {
		let e = await fetch(new URL("icons.svg", qe));
		if (!e.ok) return null;
		let t = document.createElementNS(F, "svg");
		t.id = "e-icon-sprite", t.setAttribute("aria-hidden", "true"), t.style.cssText = "position:absolute;width:0;height:0;overflow:hidden";
		let n = new DOMParser().parseFromString(await e.text(), "image/svg+xml").querySelectorAll("symbol");
		return t.append(...[...n].map((e) => document.importNode(e, !0))), t;
	} catch {
		return null;
	}
}
var Xe = class extends HTMLElement {
	async connectedCallback() {
		let e = await (Je ??= Ye()), t = this.getAttribute("name");
		if (!e || !t || !this.isConnected || this.querySelector("svg") || !e.querySelector(`symbol[id="e-icon-${CSS.escape(t)}"]`)) return;
		e.isConnected || document.body.prepend(e);
		let n = document.createElementNS(F, "svg");
		n.setAttribute("aria-hidden", "true");
		let r = document.createElementNS(F, "use");
		r.setAttribute("href", `#e-icon-${t}`), n.append(r), this.append(n);
	}
};
function Ze() {
	customElements.get("e-icon") || customElements.define("e-icon", Xe);
}
// src/v2/index-table.ts
var I = {
	en: {
		remove: (e) => `Remove ${e}`,
		selected: (e) => `${e} selected`
	},
	bn: {
		remove: (e) => `${e} সরান`,
		selected: (e) => `${v(e, "bn")}টি নির্বাচিত`
	}
}, Qe = class extends HTMLElement {
	#e = new MutationObserver(() => this.#u());
	#t = new MutationObserver(() => this.#s());
	#n;
	#r = null;
	#i = 0;
	static observedAttributes = ["label"];
	attributeChangedCallback(e, t, n) {
		n && this.isConnected && (this.hasAttribute("aria-label") && this.getAttribute("aria-label") !== t || this.setAttribute("aria-label", n));
	}
	connectedCallback() {
		let e = this.getAttribute("label");
		e && !this.hasAttribute("aria-label") && this.setAttribute("aria-label", e), this.setAttribute("role", "region"), this.#u(), this.#e.observe(this, {
			childList: !0,
			subtree: !0,
			characterData: !0
		});
		let t = this.querySelector(":scope > e-table");
		t && this.#t.observe(t, { childList: !0 }), this.#c(), this.addEventListener("change", this.#o), this.#n = D(() => {
			this.#u(), this.#l();
		});
	}
	disconnectedCallback() {
		this.#e.disconnect(), this.#t.disconnect(), this.removeEventListener("change", this.#o), this.#n?.();
	}
	#a() {
		return [...this.querySelectorAll(":scope > e-table > e-row:not([head]) > * > e-checkbox")];
	}
	#o = (e) => {
		let t = e.target instanceof Element ? e.target.closest("e-checkbox") : null;
		if (t && t.closest("e-table")?.parentElement === this) {
			if (t.closest("e-row[head]")) for (let e of this.#a()) e.checked = t.checked;
			this.#s();
		}
	};
	#s() {
		let e = this.#a(), t = 0;
		for (let n of e) n.closest("e-row")?.toggleAttribute("selected", n.checked), n.checked && (t += 1);
		let n = this.querySelector(":scope > e-table > e-row[head] > * > e-checkbox");
		n && (n.checked = t > 0 && t === e.length, n.indeterminate = t > 0 && t < e.length), this.toggleAttribute("selecting", t > 0), this.#c(), t !== this.#i && (this.#i = t, this.#l(), this.dispatchEvent(new CustomEvent("e-selection-change", {
			bubbles: !0,
			detail: { count: t }
		})));
	}
	#c() {
		let e = this.querySelector(":scope > e-table");
		e && this.toggleAttribute("empty", !e.querySelector(":scope > e-row:not([head])"));
	}
	#l() {
		let e = this.querySelector(":scope > [slot=\"bulk\"]");
		e && (this.#r || (this.#r = document.createElement("span"), this.#r.setAttribute("role", "status"), e.prepend(this.#r)), this.#r.textContent = this.#i ? I[b(this)].selected(this.#i) : "");
	}
	#u() {
		for (let e of this.querySelectorAll(":scope > [slot=\"filter\"]")) {
			let t = e.querySelector(":scope > button");
			if (!t) {
				t = document.createElement("button"), t.type = "button";
				let n = document.createElement("e-icon");
				n.setAttribute("name", "x"), t.append(n), t.addEventListener("click", () => this.#d(e)), e.append(t);
			}
			let n = I[b(e)].remove((e.textContent ?? "").trim());
			t.getAttribute("aria-label") !== n && t.setAttribute("aria-label", n);
		}
	}
	#d(e) {
		let t = e.getAttribute("name");
		e.remove(), this.querySelector(":scope > e-search-field > input")?.focus(), this.dispatchEvent(new CustomEvent("e-filter-remove", {
			bubbles: !0,
			detail: { name: t }
		}));
	}
};
function $e() {
	customElements.get("e-index-table") || customElements.define("e-index-table", Qe);
}
// src/v2/kbd.ts
function et(e) {
	return /Mac|iPhone|iPad|iPod/.test(e);
}
var tt = /* @__PURE__ */ new Map([
	["mod", {
		other: "Ctrl",
		apple: "⌘"
	}],
	["alt", {
		other: "Alt",
		apple: "⌥"
	}],
	["shift", {
		other: "Shift",
		apple: "⇧"
	}]
]);
function nt(e, t) {
	let n = et(t);
	return e.split("+").map((e) => {
		let t = tt.get(e.toLowerCase());
		return t ? n ? t.apple : t.other : e.toUpperCase();
	}).join(" ");
}
var L = "", rt = class extends HTMLElement {
	static observedAttributes = ["shortcut"];
	#e = null;
	connectedCallback() {
		this.#e || (this.#e = document.createElement("kbd"), this.replaceChildren(this.#e)), this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		this.#e && (this.#e.textContent = nt(this.getAttribute("shortcut") ?? "", L));
	}
};
function it(e = navigator.userAgent) {
	L = e, customElements.get("e-kbd") || customElements.define("e-kbd", rt);
}
// src/v2/place.ts
var R = 4, z = 8;
function B(e, t) {
	t.style.maxHeight = "";
	let n = e.getBoundingClientRect(), r = t.getBoundingClientRect(), i = n.bottom + R, a = n.top - R - r.height, o = window.innerHeight - z - i;
	r.height > o && a >= z ? i = a : r.height > o && (t.style.maxHeight = `${o}px`), t.style.left = `${Math.max(z, Math.min(n.left, window.innerWidth - z - r.width))}px`, t.style.top = `${i}px`;
}
// src/v2/menu.ts
var at = class extends HTMLElement {
	connectedCallback() {
		this.setAttribute("role", "menuitem"), this.tabIndex = -1;
	}
}, ot = class extends HTMLElement {
	#e = null;
	get #t() {
		let e = this.querySelector(":scope > [slot=\"trigger\"]");
		return e?.querySelector(":scope > button") ?? e;
	}
	get #n() {
		return [...this.#e?.querySelectorAll(":scope > e-menu-item") ?? []];
	}
	get #r() {
		return this.#e !== null && !this.#e.hidden;
	}
	connectedCallback() {
		if (!this.#e) {
			let e = document.createElement("div");
			e.setAttribute("role", "menu"), e.dataset.part = "panel", e.hidden = !0, e.append(...this.querySelectorAll(":scope > e-menu-item")), this.append(e), this.#e = e, e.addEventListener("keydown", this.#u), e.addEventListener("click", this.#l);
		}
		this.addEventListener("click", this.#s), this.#i();
	}
	disconnectedCallback() {
		this.removeEventListener("click", this.#s), document.removeEventListener("pointerdown", this.#c), this.#e && (this.#e.hidden = !0);
	}
	#i() {
		let e = this.#t;
		e?.setAttribute("aria-haspopup", "menu"), e?.setAttribute("aria-expanded", String(this.#r));
	}
	#a() {
		let e = this.#e;
		e.hidden = !1;
		let t = this.#t;
		t && B(t, e), this.#i(), document.addEventListener("pointerdown", this.#c), this.#n[0]?.focus();
	}
	#o(e) {
		this.#e.hidden = !0, document.removeEventListener("pointerdown", this.#c), this.#i(), e && this.#t?.focus();
	}
	#s = (e) => {
		this.#t && e.target instanceof Node && this.querySelector(":scope > [slot=\"trigger\"]")?.contains(e.target) && (this.#r ? this.#o(!0) : this.#a());
	};
	#c = (e) => {
		e.target instanceof Node && !this.contains(e.target) && this.#o(!1);
	};
	#l = (e) => {
		e.target instanceof Element && e.target.closest("e-menu-item") && this.#o(!0);
	};
	#u = (e) => {
		let t = this.#n, n = t.findIndex((e) => e === document.activeElement), r = (n) => {
			e.preventDefault(), t[(n + t.length) % t.length]?.focus();
		};
		e.key === "ArrowDown" ? r(n + 1) : e.key === "ArrowUp" ? r(n < 0 ? t.length - 1 : n - 1) : e.key === "Home" ? r(0) : e.key === "End" ? r(t.length - 1) : (e.key === "Enter" || e.key === " ") && n >= 0 ? (e.preventDefault(), t[n].click()) : e.key === "Escape" ? (e.preventDefault(), this.#o(!0)) : e.key === "Tab" && this.#o(!0);
	};
};
function st() {
	customElements.get("e-menu-item") || customElements.define("e-menu-item", at), customElements.get("e-menu") || customElements.define("e-menu", ot);
}
// src/host-rules.ts
var ct = {
	bn: {
		loading: "লোড হচ্ছে",
		stalled: "অ্যাপটি সাড়া দিচ্ছে না",
		reload: "আবার লোড করুন",
		unsaved: "অসংরক্ষিত পরিবর্তন",
		discard: "বাতিল",
		save: "সংরক্ষণ",
		dismiss: "বন্ধ করুন",
		leaveAsk: "সংরক্ষণ না করে চলে যাবেন?",
		leave: "চলে যান",
		stay: "থাকুন",
		close: "বন্ধ করুন",
		closeAsk: "সংরক্ষণ না করে বন্ধ করবেন?",
		keepEditing: "সম্পাদনা চালিয়ে যান",
		closeAnyway: "সংরক্ষণ না করে বন্ধ করুন",
		accessEnded: "এই স্টোরে আপনার আর অ্যাক্সেস নেই",
		chooseStore: "একটি স্টোর বেছে নিন",
		back: "ফিরে যান",
		stalledHelp: "১৫ সেকেন্ডেও অ্যাপটি সাড়া দেয়নি। আবার লোড করুন, অথবা আরও অপেক্ষা করুন।",
		keepWaiting: "অপেক্ষা করুন",
		accessHelp: "স্টোরের মালিককে আবার যোগ করতে বলুন, অথবা অন্য একটি স্টোর বেছে নিন।",
		tryAgain: "আবার চেষ্টা করুন"
	},
	en: {
		loading: "Loading",
		stalled: "This app isn't responding",
		reload: "Reload",
		unsaved: "Unsaved changes",
		discard: "Discard",
		save: "Save",
		dismiss: "Dismiss",
		leaveAsk: "Leave without saving?",
		leave: "Leave",
		stay: "Stay",
		close: "Close",
		closeAsk: "Close without saving?",
		keepEditing: "Keep editing",
		closeAnyway: "Close without saving",
		accessEnded: "You no longer have access to this store",
		chooseStore: "Choose a store",
		back: "Back",
		stalledHelp: "It hasn't answered for 15 seconds. Reload it, or keep waiting.",
		keepWaiting: "Keep waiting",
		accessHelp: "Ask the store's owner to add you again, or choose another store.",
		tryAgain: "Try again"
	}
};
new Intl.Segmenter(void 0, { granularity: "grapheme" });
// src/v2/modal.ts
var V = () => ct[document.documentElement.lang.startsWith("bn") ? "bn" : "en"];
function H(e, t) {
	let n = document.createElement("e-button");
	return n.setAttribute("type", "button"), n.dataset.part = e, t && n.setAttribute("tone", t), n;
}
function U(e, t) {
	(e.querySelector(":scope > button") ?? e).textContent = t;
}
var W = class extends HTMLElement {
	static observedAttributes = ["heading"];
	#e = null;
	#t = document.createElement("h2");
	#n = document.createElement("button");
	#r = document.createElement("footer");
	#i = [];
	#a = "clean";
	#o = H("discard");
	#s = H("save", "primary");
	#c = document.createElement("p");
	#l = H("keep-editing");
	#u = H("close-anyway", "primary");
	#d = null;
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("dialog"), t = document.createElement("header");
		this.#t.id = `${this.id || "e-modal"}-heading-${Math.random().toString(36).slice(2, 8)}`, this.#n.type = "button", this.#n.textContent = "×", this.#n.addEventListener("click", () => this.#p()), t.append(this.#t, this.#n);
		let n = document.createElement("div");
		this.#i = [...this.children].filter((e) => e.getAttribute("slot") === "footer"), this.#c.dataset.part = "ask", this.#r.append(...this.#i, this.#c, this.#l, this.#u, this.#o, this.#s), n.append(...this.childNodes), e.append(t, n, this.#r), e.setAttribute("aria-labelledby", this.#t.id), e.addEventListener("cancel", (e) => {
			this.#a !== "clean" && (e.preventDefault(), this.#f("asking"));
		}), e.addEventListener("close", () => {
			this.#a !== "clean" && this.#d?.act("discard"), this.dispatchEvent(new CustomEvent("e-modal-close", { bubbles: !0 }));
		}), this.#o.addEventListener("click", () => this.#d?.act("discard")), this.#s.addEventListener("click", () => this.#d?.act("save")), this.#l.addEventListener("click", () => this.#f("edited")), this.#u.addEventListener("click", () => e.close()), this.append(e), this.#e = e, this.#d = f(e, (e) => this.#f(e ? "edited" : "clean")), this.#f("clean"), this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		this.#t.textContent = this.getAttribute("heading") ?? "";
	}
	disconnectedCallback() {
		this.#e?.open && (this.#e.close(), document.dispatchEvent(new CustomEvent("e-modal-close", { bubbles: !0 })));
	}
	#f(e) {
		this.#a = e;
		let t = V();
		U(this.#o, t.discard), U(this.#s, t.save), this.#c.textContent = t.closeAsk, U(this.#l, t.keepEditing), U(this.#u, t.closeAnyway);
		for (let t of this.#i) t.toggleAttribute("hidden", e !== "clean");
		for (let t of [this.#o, this.#s]) t.hidden = e !== "edited";
		for (let t of [
			this.#c,
			this.#l,
			this.#u
		]) t.hidden = e !== "asking";
		this.#r.hidden = e === "clean" && this.#i.length === 0;
	}
	#p() {
		this.#a === "clean" ? this.#e?.close() : this.#f("asking");
	}
	show() {
		let e = this.#e;
		e && !e.open && (this.#n.setAttribute("aria-label", V().close), this.#f(this.#a), e.showModal(), this.dispatchEvent(new CustomEvent("e-modal-open", { bubbles: !0 })));
	}
	hide() {
		this.#e?.close();
	}
};
function lt() {
	customElements.get("e-modal") || customElements.define("e-modal", W);
}
var G = (e) => {
	let t = document.getElementById(e);
	return t instanceof W ? t : null;
}, ut = (e) => G(e)?.show(), dt = (e) => G(e)?.hide(), ft = class extends HTMLElement {
	static observedAttributes = ["heading"];
	connectedCallback() {
		let e = this.getAttribute("heading");
		if (e === null || this.querySelector(":scope > h1[slot=\"heading\"]")) return;
		let t = document.createElement("h1");
		t.slot = "heading", t.textContent = e, this.prepend(t);
	}
	attributeChangedCallback() {
		let e = this.querySelector(":scope > h1[slot=\"heading\"]");
		e && (e.textContent = this.getAttribute("heading") ?? "");
	}
};
function pt() {
	customElements.get("e-page") || customElements.define("e-page", ft);
}
// src/v2/pagination.ts
var mt = {
	en: {
		pagination: "Pagination",
		previous: "Previous page",
		next: "Next page"
	},
	bn: {
		pagination: "পাতা",
		previous: "আগের পাতা",
		next: "পরের পাতা"
	}
}, ht = class extends HTMLElement {
	static observedAttributes = [
		"label",
		"has-previous",
		"has-next"
	];
	#e = null;
	#t = null;
	#n = null;
	#r = !1;
	#i;
	connectedCallback() {
		this.#i = D(() => this.#a()), this.#e || (this.setAttribute("role", "navigation"), this.#r = this.hasAttribute("aria-label"), this.#e = document.createElement("span"), this.#t = this.#o("chevron-left", "e-previous"), this.#n = this.#o("chevron-right", "e-next"), this.append(this.#e, this.#t, this.#n), this.#a(), this.#s());
	}
	disconnectedCallback() {
		this.#i?.();
	}
	#a() {
		let e = mt[b(this)];
		this.#r || this.setAttribute("aria-label", e.pagination), this.#t?.setAttribute("aria-label", e.previous), this.#n?.setAttribute("aria-label", e.next);
	}
	attributeChangedCallback() {
		this.#s();
	}
	#o(e, t) {
		let n = document.createElement("button");
		n.type = "button";
		let r = document.createElement("e-icon");
		return r.setAttribute("name", e), n.append(r), n.addEventListener("click", () => this.dispatchEvent(new CustomEvent(t, { bubbles: !0 }))), n;
	}
	#s() {
		this.#e && this.#t && this.#n && (this.#e.textContent = this.getAttribute("label") ?? "", this.#t.disabled = !this.hasAttribute("has-previous"), this.#n.disabled = !this.hasAttribute("has-next"));
	}
};
function gt() {
	customElements.get("e-pagination") || customElements.define("e-pagination", ht);
}
// src/v2/phone-field.ts
var _t = /^01\d{9}$/, K = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value"), q = (e) => y(e).replace(/\D/g, ""), vt = {
	en: "Enter an 11-digit number starting 01",
	bn: "01 দিয়ে শুরু ১১ অঙ্কের নম্বর লিখুন"
}, yt = 0, bt = class extends C {
	build(e, t) {
		if (!(e instanceof HTMLInputElement)) return;
		e.type = "tel", e.inputMode = "tel", e.id = `e-phone-${++yt}`;
		let n = document.createElement("label");
		n.htmlFor = e.id, n.textContent = t, this.append(n, e);
		let r = () => {
			let t = e.value === "" || _t.test(e.value);
			return e.setCustomValidity(t ? "" : vt[b(this)]), t;
		};
		Object.defineProperty(e, "value", {
			get: () => K.get.call(e),
			set: (t) => {
				K.set.call(e, q(t)), r() && this.removeAttribute("error");
			}
		}), e.value = K.get.call(e), e.addEventListener("input", () => {
			let t = K.get.call(e);
			if (q(t) === t) {
				r() && this.removeAttribute("error");
				return;
			}
			let n = q(t.slice(0, e.selectionStart ?? t.length)).length;
			e.value = t, e.setSelectionRange(n, n);
		}), e.addEventListener("invalid", (t) => {
			t.preventDefault(), this.setAttribute("error", e.validationMessage), e.form?.querySelector(":invalid") === e && e.focus();
		});
	}
	relabel(e, t) {
		let n = e.labels?.[0];
		n && (n.textContent = t);
	}
};
function xt() {
	customElements.get("e-phone-field") || customElements.define("e-phone-field", bt);
}
// src/v2/popover.ts
var St = 0, Ct = class extends HTMLElement {
	static observedAttributes = ["label"];
	#e = null;
	#t = new MutationObserver(() => this.#a());
	get #n() {
		return this.querySelector(":scope > [slot=\"trigger\"]");
	}
	get #r() {
		let e = this.#n;
		return e?.localName.includes("-") ? e.querySelector(":scope > button") : e;
	}
	get #i() {
		return this.#e !== null && !this.#e.hidden;
	}
	connectedCallback() {
		if (!this.#e) {
			let e = document.createElement("div");
			e.setAttribute("role", "dialog"), e.id = `e-popover-${++St}`, e.dataset.part = "panel", e.hidden = !0, e.append(...[...this.childNodes].filter((e) => e !== this.#n)), this.append(e), this.#e = e, this.attributeChangedCallback();
		}
		this.addEventListener("click", this.#l), this.#t.observe(this, {
			childList: !0,
			subtree: !0
		}), this.#a();
	}
	attributeChangedCallback() {
		let e = this.getAttribute("label");
		e === null ? this.#e?.removeAttribute("aria-label") : this.#e?.setAttribute("aria-label", e);
	}
	disconnectedCallback() {
		this.removeEventListener("click", this.#l), this.#t.disconnect(), this.#i && this.#c(!1);
	}
	#a() {
		let e = this.#r;
		e?.setAttribute("aria-haspopup", "dialog"), e?.setAttribute("aria-expanded", String(this.#i)), e?.setAttribute("aria-controls", this.#e.id);
	}
	#o = () => {
		let e = this.#r;
		e && B(e, this.#e);
	};
	#s() {
		this.#e.hidden = !1, this.#o(), this.#a(), document.addEventListener("pointerdown", this.#u), document.addEventListener("keydown", this.#d), document.addEventListener("scroll", this.#o, !0), window.addEventListener("resize", this.#o);
	}
	#c(e) {
		this.#e.hidden = !0, document.removeEventListener("pointerdown", this.#u), document.removeEventListener("keydown", this.#d), document.removeEventListener("scroll", this.#o, !0), window.removeEventListener("resize", this.#o), this.#a(), e && this.#r?.focus();
	}
	#l = (e) => {
		e.target instanceof Node && this.#n?.contains(e.target) && (this.#i ? this.#c(!0) : this.#s());
	};
	#u = (e) => {
		e.target instanceof Node && !this.contains(e.target) && this.#c(!1);
	};
	#d = (e) => {
		e.key === "Escape" && (e.preventDefault(), this.#c(!0));
	};
};
function wt() {
	customElements.get("e-popover") || customElements.define("e-popover", Ct);
}
// src/v2/progress-bar.ts
var Tt = class extends HTMLElement {
	static observedAttributes = ["value", "label"];
	connectedCallback() {
		this.setAttribute("role", "progressbar"), this.setAttribute("aria-valuemin", "0"), this.setAttribute("aria-valuemax", "100"), this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		let e = this.getAttribute("label");
		e !== null && this.setAttribute("aria-label", e);
		let t = Number.parseFloat(this.getAttribute("value") ?? "");
		if (Number.isNaN(t)) {
			this.removeAttribute("aria-valuenow"), this.style.removeProperty("--e-progress");
			return;
		}
		let n = Math.min(100, Math.max(0, t));
		this.setAttribute("aria-valuenow", String(n)), this.style.setProperty("--e-progress", `${n}%`);
	}
};
function Et() {
	customElements.get("e-progress-bar") || customElements.define("e-progress-bar", Tt);
}
// src/v2/select.ts
var Dt = 0, Ot = class extends HTMLElement {
	static observedAttributes = [
		"label",
		"disabled",
		"error"
	];
	#e = null;
	get value() {
		return this.#e?.value ?? "";
	}
	set value(e) {
		this.#e && (this.#e.value = e);
	}
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("select");
		e.id = `e-select-${++Dt}`;
		let t = this.getAttribute("name");
		t !== null && (e.name = t), e.disabled = this.hasAttribute("disabled"), e.append(...this.querySelectorAll(":scope > option")), this.#e = e;
		let n = this.getAttribute("label") ?? "";
		if (this.hasAttribute("hide-label")) e.setAttribute("aria-label", n), this.append(e);
		else {
			let t = document.createElement("label");
			t.htmlFor = e.id, t.textContent = n, this.append(t, e);
		}
		S(this, e);
	}
	attributeChangedCallback(e, t, n) {
		let r = this.#e;
		r && (e === "disabled" ? r.disabled = n !== null : e === "error" ? S(this, r) : this.hasAttribute("hide-label") ? r.setAttribute("aria-label", n ?? "") : r.labels[0].textContent = n ?? "");
	}
};
function kt() {
	customElements.get("e-select") || customElements.define("e-select", Ot);
}
// src/v2/settings-section.ts
var At = class extends HTMLElement {
	static observedAttributes = ["heading", "help"];
	connectedCallback() {
		if (this.querySelector(":scope > [slot=\"heading\"], :scope > [slot=\"help\"]")) return;
		let e = document.createElement("h2");
		e.slot = "heading";
		let t = document.createElement("p");
		t.slot = "help", this.prepend(e, t), this.attributeChangedCallback();
	}
	attributeChangedCallback() {
		let e = this.querySelector(":scope > h2[slot=\"heading\"]"), t = this.querySelector(":scope > p[slot=\"help\"]");
		e && (e.textContent = this.getAttribute("heading") ?? ""), t && (t.textContent = this.getAttribute("help") ?? "");
	}
};
function jt() {
	customElements.get("e-settings-section") || customElements.define("e-settings-section", At);
}
// src/v2/setup-guide.ts
var Mt = 0, Nt = "০১২৩৪৫৬৭৮৯", Pt = class extends HTMLElement {
	static observedAttributes = ["done"];
	#e = null;
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("input");
		e.type = "checkbox", e.id = `e-setup-step-${++Mt}`, e.checked = this.hasAttribute("done"), e.addEventListener("change", () => this.toggleAttribute("done", e.checked));
		let t = document.createElement("label");
		t.htmlFor = e.id, t.append(...this.childNodes), this.#e = e, this.append(e, t);
	}
	attributeChangedCallback() {
		this.#e && (this.#e.checked = this.hasAttribute("done"));
	}
}, Ft = class extends HTMLElement {
	static observedAttributes = ["heading"];
	#e = new MutationObserver(() => this.#t());
	connectedCallback() {
		if (!this.querySelector(":scope > [data-count]")) {
			let e = this.getAttribute("heading");
			if (e !== null) {
				let t = document.createElement("h2");
				t.slot = "heading", t.textContent = e, this.prepend(t);
			}
			let t = document.createElement("button");
			t.type = "button", t.dataset.dismiss = "", t.addEventListener("click", () => {
				this.dispatchEvent(new CustomEvent("dismiss", { bubbles: !0 })), this.remove();
			});
			let n = document.createElement("span");
			n.dataset.count = "";
			let r = this.querySelector(":scope > h2[slot=\"heading\"]");
			r ? r.after(t, n) : this.prepend(t, n);
		}
		this.#t(), this.#e.observe(this, {
			subtree: !0,
			childList: !0,
			attributes: !0,
			attributeFilter: ["done"]
		}), this.#e.observe(document.documentElement, {
			attributes: !0,
			attributeFilter: ["lang"]
		});
	}
	disconnectedCallback() {
		this.#e.disconnect();
	}
	attributeChangedCallback() {
		let e = this.querySelector(":scope > h2[slot=\"heading\"]");
		e && (e.textContent = this.getAttribute("heading") ?? "");
	}
	#t() {
		let e = this.querySelectorAll("e-setup-step"), t = this.querySelectorAll("e-setup-step[done]").length, n = this.closest("[lang]")?.getAttribute("lang")?.startsWith("bn"), r = (e) => n ? String(e).replace(/\d/g, (e) => Nt[Number(e)]) : String(e), i = (e, t) => {
			let n = this.querySelector(`:scope > ${e}`);
			n.textContent !== t && (n.textContent = t);
		};
		i("[data-count]", n ? `${r(e.length)}টির মধ্যে ${r(t)}টি` : `${t} of ${e.length}`), i("[data-dismiss]", n ? "বাদ দিন" : "Dismiss");
	}
};
function It() {
	customElements.get("e-setup-guide") || customElements.define("e-setup-guide", Ft), customElements.get("e-setup-step") || customElements.define("e-setup-step", Pt);
}
// src/v2/spinner.ts
var Lt = class extends HTMLElement {
	#e = !1;
	#t = new MutationObserver(() => this.#n());
	connectedCallback() {
		if (this.setAttribute("role", "status"), !this.hasAttribute("aria-label") || this.#e) {
			this.#e = !0, this.#n();
			for (let e of /* @__PURE__ */ new Set([this.closest("[lang]"), document.documentElement])) e && this.#t.observe(e, { attributeFilter: ["lang"] });
		}
	}
	disconnectedCallback() {
		this.#t.disconnect();
	}
	#n() {
		this.setAttribute("aria-label", b(this) === "bn" ? "লোড হচ্ছে" : "Loading");
	}
};
function Rt() {
	customElements.get("e-spinner") || customElements.define("e-spinner", Lt);
}
// src/v2/switch.ts
var zt = 0, Bt = class extends HTMLElement {
	static observedAttributes = [
		"label",
		"disabled",
		"error"
	];
	#e = null;
	get checked() {
		return this.#e ? this.#e.checked : this.hasAttribute("checked");
	}
	set checked(e) {
		this.#e ? this.#e.checked = e : this.toggleAttribute("checked", e);
	}
	connectedCallback() {
		if (this.#e) return;
		let e = document.createElement("input");
		e.type = "checkbox", e.setAttribute("role", "switch"), e.id = `e-switch-${++zt}`;
		for (let t of ["name", "value"]) {
			let n = this.getAttribute(t);
			n !== null && e.setAttribute(t, n);
		}
		e.checked = this.hasAttribute("checked"), e.disabled = this.hasAttribute("disabled");
		let t = document.createElement("label");
		t.htmlFor = e.id, t.textContent = this.getAttribute("label") ?? "", this.#e = e, this.append(e, t), S(this, e);
	}
	attributeChangedCallback(e, t, n) {
		let r = this.#e;
		r && (e === "disabled" ? r.disabled = n !== null : e === "error" ? S(this, r) : r.labels[0].textContent = n ?? "");
	}
};
function Vt() {
	customElements.get("e-switch") || customElements.define("e-switch", Bt);
}
// src/v2/table.ts
var Ht = class extends HTMLElement {
	static observedAttributes = ["label"];
	connectedCallback() {
		this.setAttribute("role", "table");
		let e = this.getAttribute("label");
		e && !this.hasAttribute("aria-label") && this.setAttribute("aria-label", e);
		let t = this.getAttribute("columns");
		t && !this.style.getPropertyValue("--e-columns") && this.style.setProperty("--e-columns", t);
	}
	attributeChangedCallback(e, t, n) {
		t !== null && n && this.getAttribute("aria-label") === t && this.setAttribute("aria-label", n);
	}
}, Ut = class extends HTMLElement {
	seen = new MutationObserver(() => this.build());
	connectedCallback() {
		this.setAttribute("role", "row"), this.build(), this.seen.observe(this, { childList: !0 });
	}
	disconnectedCallback() {
		this.seen.disconnect();
	}
	build() {
		let e = this.hasAttribute("head") ? "columnheader" : "cell";
		for (let t of this.children) t.matches("a[href]") || t.hasAttribute("role") || t.setAttribute("role", e);
	}
};
function Wt() {
	customElements.get("e-table") || customElements.define("e-table", Ht), customElements.get("e-row") || customElements.define("e-row", Ut);
}
// src/v2/tabs.ts
var J = class extends HTMLElement {
	static observedAttributes = ["selected", "count"];
	#e = new MutationObserver(() => this.#n());
	connectedCallback() {
		this.setAttribute("role", "tab"), this.#t(), this.#n(), this.#e.observe(this, {
			childList: !0,
			characterData: !0,
			subtree: !0
		});
	}
	disconnectedCallback() {
		this.#e.disconnect();
	}
	attributeChangedCallback(e) {
		if (this.isConnected) {
			if (e === "count") this.#n();
			else {
				if (this.hasAttribute("selected")) for (let e of this.parentElement?.querySelectorAll(":scope > e-tab[selected]") ?? []) e !== this && e.removeAttribute("selected");
				this.#t();
			}
		}
	}
	#t() {
		let e = this.hasAttribute("selected"), t = !this.parentElement?.querySelector(":scope > e-tab[selected]"), n = this.parentElement?.querySelector(":scope > e-tab") === this;
		this.setAttribute("aria-selected", String(e)), this.setAttribute("tabindex", e || t && n ? "0" : "-1");
	}
	#n() {
		let e = this.getAttribute("count");
		e ? this.setAttribute("aria-label", `${this.textContent.trim()} ${e}`) : this.removeAttribute("aria-label");
	}
}, Gt = class extends HTMLElement {
	static observedAttributes = ["label"];
	connectedCallback() {
		this.setAttribute("role", "tablist"), this.#e(), this.addEventListener("click", this.#r), this.addEventListener("keydown", this.#i);
	}
	disconnectedCallback() {
		this.removeEventListener("click", this.#r), this.removeEventListener("keydown", this.#i);
	}
	attributeChangedCallback() {
		this.isConnected && this.#e();
	}
	#e() {
		let e = this.getAttribute("label");
		e && this.setAttribute("aria-label", e);
	}
	#t(e) {
		let t = e.target instanceof Element ? e.target.closest("e-tab") : null;
		return t instanceof J ? t : null;
	}
	#n(e) {
		e.hasAttribute("selected") || (e.setAttribute("selected", ""), this.dispatchEvent(new CustomEvent("e-tab-change", {
			bubbles: !0,
			detail: { value: e.getAttribute("value") }
		})));
	}
	#r = (e) => {
		let t = this.#t(e);
		t && this.#n(t);
	};
	#i = (e) => {
		let t = this.#t(e);
		if (!t) return;
		let n = [...this.querySelectorAll(":scope > e-tab")], r = n.indexOf(t), i;
		e.key === "ArrowRight" ? i = n[(r + 1) % n.length] : e.key === "ArrowLeft" ? i = n[(r - 1 + n.length) % n.length] : e.key === "Home" ? i = n[0] : e.key === "End" ? i = n[n.length - 1] : (e.key === "Enter" || e.key === " ") && (i = t), i && (e.preventDefault(), this.#n(i), i.focus());
	};
};
function Kt() {
	customElements.get("e-tab") || customElements.define("e-tab", J), customElements.get("e-tabs") || customElements.define("e-tabs", Gt);
}
// src/v2/taka-field.ts
var Y = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value"), qt = 0, Jt = class extends HTMLElement {
	static observedAttributes = ["label", "error"];
	#e = null;
	#t = null;
	#n;
	connectedCallback() {
		if (this.#n = D(() => this.#r()), this.#e) return;
		let e = document.createElement("input");
		e.id = `e-taka-${++qt}`, e.inputMode = "decimal";
		let t = document.createElement("label");
		t.htmlFor = e.id, t.textContent = this.getAttribute("label") ?? "";
		let n = document.createElement("span");
		n.dataset.ePrefix = "", n.setAttribute("aria-hidden", "true"), n.textContent = "৳";
		let r = document.createElement("input");
		r.type = "hidden";
		let i = this.getAttribute("name");
		i !== null && (r.name = i), r.value = this.getAttribute("value") ?? "";
		let a = !1;
		Object.defineProperty(r, "value", {
			get: () => Y.get.call(r),
			set: (e) => {
				Y.set.call(r, e), a || this.#r();
			}
		}), e.addEventListener("input", () => {
			a = !0, r.value = y(e.value).replace(/[^\d.]/g, ""), a = !1, r.dispatchEvent(new Event("input", { bubbles: !0 }));
		}), e.addEventListener("change", () => r.dispatchEvent(new Event("change", { bubbles: !0 }))), e.addEventListener("blur", () => this.#r()), this.#e = e, this.#t = r, this.append(t, e, n, r), this.#r(), S(this, e);
	}
	disconnectedCallback() {
		this.#n?.();
	}
	attributeChangedCallback(e, t, n) {
		let r = this.#e;
		r && (e === "error" ? S(this, r) : r.labels[0].textContent = n ?? "");
	}
	#r() {
		let e = this.#t.value, t = Number(e);
		this.#e.value = e === "" || Number.isNaN(t) ? e : v(t, b(this));
	}
};
function Yt() {
	customElements.get("e-taka-field") || customElements.define("e-taka-field", Jt);
}
// src/v2/text.ts
var Xt = class extends HTMLElement {
	connectedCallback() {
		this.setAttribute("role", "heading"), this.setAttribute("aria-level", this.getAttribute("level") ?? "2");
	}
};
function Zt() {
	customElements.get("e-heading") || customElements.define("e-heading", Xt);
}
// src/v2/tooltip.ts
var Qt = 0, X = "a[href], button, input, select, textarea, [tabindex]", $t = class extends HTMLElement {
	static observedAttributes = ["text"];
	#e = null;
	#t = !1;
	#n = !1;
	#r = !1;
	#i = new MutationObserver(() => this.#s());
	get #a() {
		let e = this.firstElementChild;
		return e instanceof HTMLElement && e !== this.#e ? e : null;
	}
	get #o() {
		let e = this.#a;
		return e?.matches(X) ? e : e?.querySelector(X) ?? null;
	}
	connectedCallback() {
		if (!this.#e) {
			let e = document.createElement("div");
			e.setAttribute("role", "tooltip"), e.id = `e-tooltip-${++Qt}`, e.dataset.part = "bubble", e.hidden = !0, e.textContent = this.getAttribute("text") ?? "", this.append(e), this.#e = e;
		}
		this.addEventListener("pointerenter", this.#l), this.addEventListener("pointerleave", this.#u), this.addEventListener("focusin", this.#d), this.addEventListener("focusout", this.#f), this.#i.observe(this, {
			childList: !0,
			subtree: !0
		}), this.#s();
	}
	disconnectedCallback() {
		this.removeEventListener("pointerenter", this.#l), this.removeEventListener("pointerleave", this.#u), this.removeEventListener("focusin", this.#d), this.removeEventListener("focusout", this.#f), this.#i.disconnect(), this.#c(!1, !1);
	}
	attributeChangedCallback() {
		this.#e && (this.#e.textContent = this.getAttribute("text") ?? "", this.#s());
	}
	#s() {
		let e = this.#a;
		if (!e || !this.#e) return;
		let t = this.#e.textContent ?? "";
		this.#r || !e.hasAttribute("aria-label") && !e.textContent?.trim() ? (this.#r = !0, e.getAttribute("aria-label") !== t && e.setAttribute("aria-label", t)) : this.#o?.setAttribute("aria-describedby", this.#e.id);
	}
	#c(e, t) {
		this.#t = e, this.#n = t;
		let n = this.#e, r = this.#a;
		if (!n || !r) return;
		let i = e || t;
		i !== !n.hidden && (n.hidden = !i, i ? (B(r, n), document.addEventListener("keydown", this.#p, !0)) : document.removeEventListener("keydown", this.#p, !0));
	}
	#l = () => this.#c(!0, this.#n);
	#u = () => this.#c(!1, this.#n);
	#d = (e) => {
		e.target instanceof Element && e.target.matches(":focus-visible") && this.#c(this.#t, !0);
	};
	#f = () => this.#c(this.#t, !1);
	#p = (e) => {
		e.key === "Escape" && (e.stopPropagation(), e.preventDefault(), this.#c(!1, !1));
	};
};
function en() {
	customElements.get("e-tooltip") || customElements.define("e-tooltip", $t);
}
// src/v2.ts
var Z = re(window);
Z && location.replace(Z), Se(), Ze(), ke(), Fe(), Vt(), we(), lt(), pt(), Zt(), Wt(), le(), Kt(), gt(), Ge(), Me(), xt(), Yt(), kt(), Ue(), Le(), $e(), st(), be(), it(), jt(), It(), wt(), en(), pe(), Et(), Rt();
var Q = ae(), tn = Object.assign((e) => Q.modal(e), {
	show: ut,
	hide: dt
}), $ = {
	...Q,
	...ge(),
	modal: tn,
	format: {
		digits: v,
		phone: y,
		taka: se
	},
	showErrors: o
};
me(), Ke(window, $), _e(), ve(), Object.assign(globalThis, { ebdfy: $ });
export { $ as ebdfy };
